import { Home } from "./Pages/Home";
import "./Assets/Css/App.css";

export function App() {
  return (
    <div id="App">
      <Home />
    </div>
  );
}
